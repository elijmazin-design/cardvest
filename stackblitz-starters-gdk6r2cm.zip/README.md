// --- AUTO-UPDATING NEWS TICKER ---
export const NewsTicker = () => {
    const [news, setNews] = useState([]);
    useEffect(() => {
        // Automatically pops up when DB changes
        const sub = supabase.channel('news').on('postgres_changes', { event: 'INSERT', table: 'news' }, 
            payload => setNews(prev => [payload.new, ...prev].slice(0, 20))).subscribe();
        return () => supabase.removeChannel(sub);
    }, []);

    return (
        <div className="bg-black text-green-400 p-2 flex overflow-x-auto whitespace-nowrap border-b border-gray-800">
            {news.map(n => <span key={n.id} className="mx-4">● {n.headline}</span>)}
        </div>
    );
};

// --- SEARCH WITH SUGGESTIONS & IMAGES ---
export const SmartSearch = () => {
    const [results, setResults] = useState([]);
    const handleTyping = async (q) => {
        const { data } = await supabase.from('cards').select('*, players(name)').ilike('players.name', `%${q}%`).limit(5);
        setResults(data);
    };
    return (
        <div className="relative">
            <input className="bg-gray-900 text-white p-4 w-full rounded" onChange={e => handleTyping(e.target.value)} placeholder="Type a card..." />
            {results.map(c => (
                <div className="flex p-2 hover:bg-gray-800 border-b border-gray-700">
                    <img src={c.image_url} className="w-8 h-10 mr-2" />
                    <span>{c.year} {c.players.name} {c.brand}</span>
                </div>
            ))}
        </div>
    );
};

// --- BREAK PRICE CALCULATOR ---
export const BreakTool = ({ totalCasePrice, teamChecklistValue }) => {
    const fairPrice = (totalCasePrice * teamChecklistValue * 1.15).toFixed(2);
    return (
        <div className="p-4 bg-gray-900 border border-blue-500 rounded">
            <h4 className="text-white">Fair Team Buy-in</h4>
            <p className="text-2xl text-green-400 font-mono">${fairPrice}</p>
        </div>
    );
};